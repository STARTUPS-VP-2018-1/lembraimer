package br.com.lembraimer.interfaces.test;

import br.com.lembraimer.dominio.Usuario;

public interface UsuarioInterfaceMock {
    
    public  boolean checkLogin(String nome, String nomeResponsavel);
    
    public Usuario usuarioLogado(Usuario usuario, Usuario senha);
}
