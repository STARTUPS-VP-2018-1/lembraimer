package br.com.lembraimer.business.test;

import br.com.lembraimer.business.interfaces.UsuarioInterface;
import br.com.lembraimer.db.DataBase;
import br.com.lembraimer.dominio.Endereco;
import br.com.lembraimer.dominio.Paciente;
import br.com.lembraimer.dominio.Usuario;
import br.com.lembraimer.tela.TelaUsuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class UsuarioBusinessMock implements UsuarioInterface{ 
    
    @Override
    public boolean checkLogin(String nomeLogin, String nomeResponsavel) {
        Connection conn;
    PreparedStatement cmd;
    ResultSet rs;
    
    boolean check = false;
    conn = DataBase.conexao();
        try {
            cmd = conn.prepareStatement("SELECT * FROM paciente where nomePaciente = ? and nomeResponsavel = ?");
            cmd.setString(1, "Lucas");
            cmd.setString(2, "Yuri");
            rs = cmd.executeQuery();
            while(rs.next()){
                check = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioBusinessMock.class.getName()).log(Level.SEVERE, null, ex);
        }
        return check;
    }
    

    @Override
    public Usuario usuarioLogado(Usuario usuario, Usuario senha) {
        
        
        
        if(this.checkLogin(usuario.getLogin(), senha.getSenha())){
            try {
            PreparedStatement cmd;
            Connection conn;
            ResultSet rs;
            
            conn = DataBase.conexao();
            
            String query = "SELECT * FROM paciente where nomePaciente = ? and nomeResponsavel = ?";

            cmd = conn.prepareStatement(query);
            
            cmd.setString(1, "Lucas");
            cmd.setString(2, "Teste123");
            
            rs = cmd.executeQuery();
            
            Paciente paciente = new Paciente();
            Endereco endereco = new Endereco();
            
            while(rs.next()){
                  paciente.setId(Integer.parseInt(rs.getString("Id")));
                  paciente.setNomePaciente(rs.getString("nomePaciente"));
                  paciente.setNomeResponsavel(rs.getString("nomeResponsavel"));
                  paciente.setTelefone(Integer.parseInt(rs.getString("telefoneResponsavel")));
                  paciente.setRemedio(rs.getString("medicamento"));
                  paciente.setHorarioMedicamento(rs.getString("horarioMedicamento"));
                  endereco.setRua(rs.getString("endereco"));
                  paciente.setLembrete(rs.getString("lembretes"));
            }
            //teste certo
            TelaUsuario novaTela = new TelaUsuario(paciente.getNomePaciente(), paciente.getNomeResponsavel(), paciente.getTelefone(), endereco.getRua(), paciente.getHorarioMedicamento(), paciente.getLembrete());
            novaTela.setVisible(true);
            
            
            DataBase.fecharfecharConexao(conn, cmd, rs);                            
             } catch(SQLException ex){
            System.out.println("Erro de conexão " + ex.getMessage());
        }
     
     }else{
            JOptionPane.showMessageDialog(null, "Erro de usuario");
        }
        return null;
    }
    
    public void  notificacao(Paciente nome){        
    Connection conn;
    PreparedStatement cmd;
    ResultSet rs ;
        
    conn = DataBase.conexao();
    //Paciente pass = new Paciente();
        try {
            cmd = conn.prepareStatement("SELECT nomeResponsavel from paciente where nomePaciente = ?");
            
            cmd.setString(1, "Lucas");
            
            //cmd.setString(2, nome.getNomeResponsavel());
            
            rs = cmd.executeQuery();

            JOptionPane.showMessageDialog(null, "Yuri");

            DataBase.fecharfecharConexao(conn, cmd, rs);
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioBusinessMock.class.getName()).log(Level.SEVERE, null, ex);
        }
  
    }
}
