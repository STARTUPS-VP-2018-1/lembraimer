package br.com.lembraimer.business;

import br.com.lembraimer.business.interfaces.PacienteInterface;
import br.com.lembraimer.dominio.Paciente;
import br.com.lembraimer.banco.BancoDeDados;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PacienteBusiness implements PacienteInterface {

    @Override
    
    public Paciente salvarPaciente(Paciente paciente) {
       if(validarPaciente(paciente)){
           BancoDeDados.pacienteBDFake.add(paciente);
           JOptionPane.showMessageDialog(null,"Paciente cadastrado com sucesso!!!");
           JOptionPane.showMessageDialog(null, " O Paciente com ID = "+paciente.getId()+
                " foi cadastrado com sucesso!");
       }else{
           JOptionPane.showMessageDialog(null,"TODOS OS CAMPOS DEVEM SER PREENCHIDOS");
       }
      
            return null;
    }

    @Override
    public Paciente buscarPacientePorId(Integer id) {
        for(Paciente paciente: BancoDeDados.pacienteBDFake){
            if(paciente.getId() == id){
                return paciente;
            }
        } 
        return null;
    }

    @Override
    public List<Paciente> buscarPacientePorNome(String nome) {
        List<Paciente> listaDePacientesEncontrados = new ArrayList<Paciente>();        
        
        for(int i = 0; i< BancoDeDados.pacienteBDFake.size();i++){
            Paciente paciente = BancoDeDados.pacienteBDFake.get(i);
            if(paciente.getNomePaciente().startsWith(nome)){
                listaDePacientesEncontrados.add(paciente);
            }           
        }
        return listaDePacientesEncontrados;
    }

    @Override
    public List<Paciente> buscarTodosPacientes() {
        return BancoDeDados.pacienteBDFake;
    }
    
        public boolean validarPaciente(Paciente paciente){
        boolean clienteValido = true;
        if(paciente !=null)
        {
            if(paciente.getNomePaciente()==null||
                paciente.getNomePaciente().equals("")||
                paciente.getNomeResponsavel()==null||
                paciente.getRemedio()==null||
                paciente.getRemedio().equals("")||
                paciente.getTelefone()==null||
                paciente.getTelefone().equals(""))
                {
                clienteValido = false;
                }
        }
        return clienteValido;
     }
}
