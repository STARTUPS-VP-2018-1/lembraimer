package br.com.lembraimer.business.interfaces;

import java.util.List;
import br.com.lembraimer.dominio.Paciente;
        
public interface PacienteInterface {
    
    public Paciente salvarPaciente(Paciente paciente);
    
    public Paciente buscarPacientePorId(Integer id);
    
    public List<Paciente> buscarPacientePorNome(String nome);
    
    public List<Paciente> buscarTodosPacientes();
}
