package lembraime;

import br.com.lembraime.telaCadastro.TelaPrincipal;



public class Lembraime {

    public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
        
        
    }
    
}
