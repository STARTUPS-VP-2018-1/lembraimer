package br.com.lembraimer.tela;
import br.com.lembraimer.dominio.Paciente;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import br.com.lembraimer.banco.BancoDeDados;
import br.com.lembraimer.business.PacienteBusiness;
import br.com.lembraimer.business.interfaces.PacienteInterface;


public class TelaCadastro extends javax.swing.JFrame {
        

    public TelaCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        nomePaciente = new javax.swing.JLabel();
        medicamentos = new javax.swing.JLabel();
        nomeResponsavel = new javax.swing.JLabel();
        telefoneResponsavel = new javax.swing.JLabel();
        nomePacienteTxt = new javax.swing.JTextField();
        medicamentoTxt = new javax.swing.JTextField();
        nomeResponsavelTxt = new javax.swing.JTextField();
        botaoCancelar = new javax.swing.JButton();
        botaoSalvar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        telefoneTxt = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel1.setText("CADASTRO DO PACIENTE");

        nomePaciente.setBackground(new java.awt.Color(0, 0, 0));
        nomePaciente.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        nomePaciente.setText("Nome do Paciente: ");

        medicamentos.setBackground(new java.awt.Color(0, 0, 0));
        medicamentos.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        medicamentos.setText("Medicamento:");

        nomeResponsavel.setBackground(new java.awt.Color(0, 0, 0));
        nomeResponsavel.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        nomeResponsavel.setText("Nome do Responsável:");

        telefoneResponsavel.setBackground(new java.awt.Color(0, 0, 0));
        telefoneResponsavel.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        telefoneResponsavel.setText("Telefone do Responsável:");

        nomePacienteTxt.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        nomePacienteTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomePacienteTxtActionPerformed(evt);
            }
        });

        medicamentoTxt.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        medicamentoTxt.setToolTipText("");
        medicamentoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medicamentoTxtActionPerformed(evt);
            }
        });

        nomeResponsavelTxt.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N

        botaoCancelar.setFont(new java.awt.Font("Verdana", 0, 14)); // NOI18N
        botaoCancelar.setForeground(new java.awt.Color(200, 0, 0));
        botaoCancelar.setText("Cancelar");
        botaoCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCancelarActionPerformed(evt);
            }
        });

        botaoSalvar.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        botaoSalvar.setForeground(new java.awt.Color(0, 200, 0));
        botaoSalvar.setText("Salvar");
        botaoSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoSalvarActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2);

        telefoneTxt.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));
        telefoneTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefoneTxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nomePaciente)
                        .addGap(80, 80, 80)
                        .addComponent(nomePacienteTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nomeResponsavel)
                            .addComponent(medicamentos)
                            .addComponent(telefoneResponsavel)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(botaoSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(telefoneTxt, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(nomeResponsavelTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(medicamentoTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(botaoCancelar)))))
                .addGap(0, 20, Short.MAX_VALUE))
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nomePaciente)
                    .addComponent(nomePacienteTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(medicamentos)
                    .addComponent(medicamentoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nomeResponsavel)
                    .addComponent(nomeResponsavelTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telefoneResponsavel)
                    .addComponent(telefoneTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botaoSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botaoCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    Integer ID = 0;
    int telefone =0;
    
    private void botaoSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoSalvarActionPerformed
        
        
        Paciente novoPaciente = new Paciente();
       
        
        try{
        novoPaciente.setNomePaciente(this.nomePacienteTxt.getText());
        novoPaciente.setRemedio(this.medicamentoTxt.getText());
        novoPaciente.setNomeResponsavel(this.nomeResponsavelTxt.getText());
        novoPaciente.setTelefone(Integer.parseInt(this.telefoneTxt.getText()));
        ID = ID + 1;
        novoPaciente.setId(ID);
        }catch(NumberFormatException exc){ 
        }  
        PacienteBusiness pacienteSalvar = new PacienteBusiness();
        //pacienteSalvar.salvarPaciente(novoPaciente);
        
        
        
        
        
        //Tabela de visão
        jTable2 = new JTable();
        DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("NOME PACIENTE");
        modelo.addColumn("MEDICAMENTOS");
        modelo.addColumn("NOME DO RESPONSAVEL");
        modelo.addColumn("TELEFONE");
        
        for(Paciente cadastroPaciente : BancoDeDados.pacienteBDFake)
        {
            Object[] objeto = new Object [5];
            objeto[0] = cadastroPaciente.getId();
            objeto[1] = cadastroPaciente.getNomePaciente();
            objeto[2] = cadastroPaciente.getRemedio();
            objeto[3] = cadastroPaciente.getNomeResponsavel();
            objeto[4] = cadastroPaciente.getTelefone();
            modelo.addRow(objeto);
        }
        
        jTable2.setModel(modelo);
        jTable2.setToolTipText("");
        jScrollPane2.setViewportView(jTable2);
        
        
        //Para limpar a tela ao salvar 
        nomePacienteTxt.setText("");
        medicamentoTxt.setText("");
        nomeResponsavelTxt.setText("");
        telefoneTxt.setText("");
        
     
     
    }//GEN-LAST:event_botaoSalvarActionPerformed

    private void botaoCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCancelarActionPerformed
                 System.exit(0);
    }//GEN-LAST:event_botaoCancelarActionPerformed

    private void nomePacienteTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomePacienteTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomePacienteTxtActionPerformed

    private void medicamentoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medicamentoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_medicamentoTxtActionPerformed

    private void telefoneTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefoneTxtActionPerformed
        // TODO add your handling code here:
        
        
        
        
    }//GEN-LAST:event_telefoneTxtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoCancelar;
    private javax.swing.JButton botaoSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField medicamentoTxt;
    private javax.swing.JLabel medicamentos;
    private javax.swing.JLabel nomePaciente;
    private javax.swing.JTextField nomePacienteTxt;
    private javax.swing.JLabel nomeResponsavel;
    private javax.swing.JTextField nomeResponsavelTxt;
    private javax.swing.JLabel telefoneResponsavel;
    private javax.swing.JFormattedTextField telefoneTxt;
    // End of variables declaration//GEN-END:variables
    private javax.swing.JTextField dataNascimentoTxt;
}
