package br.com.lembraimer.banco;

import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;
import br.com.lembraimer.dominio.Endereco;
import br.com.lembraimer.dominio.Paciente;
import br.com.lembraimer.dominio.Responsavel;

public class BancoDeDados {
    
    public static List<Paciente> pacienteBDFake = new LinkedList<Paciente>();
    public static List<Responsavel> responsavelBDFake = new ArrayList<Responsavel>();
    public static List<Endereco> enderecoBDFake = new ArrayList<Endereco>();
}
