package br.com.lembraimer.business;

import br.com.lembraimer.business.interfaces.PacienteInterface;
import br.com.lembraimer.dominio.Paciente;
import br.com.lembraimer.banco.BancoDeDados;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import br.com.lembraimer.dominio.Endereco;
import java.sql.ResultSet;

public class PacienteBusiness implements PacienteInterface {

    @Override
    public Paciente salvarPaciente(Paciente paciente, Endereco endereco) {
        
       if(validarPaciente(paciente) || validarEndereco(endereco)){
           try {
            //cria variavel de conexão
            java.sql.Connection con;
            
            //cria conexão(pega) com o banco de dados
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/lembraimer?useTimezone=true&serverTimezone=UTC","root","root");
            
            //cria a string para inserir no banco
            String query = "INSERT INTO paciente (Id, nomePaciente, nomeResponsavel, telefoneResponsavel, "
                    + "medicamento,horarioMedicamento, endereco, lembretes) VALUES(?,?,?,?,?,?,?,?)";
            
            //seta os valores na string de inserção
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, "1");
            stmt.setString(2, paciente.getNomePaciente());
            stmt.setString(3, paciente.getNomeResponsavel());
            stmt.setString(4, String.valueOf(paciente.getTelefone()));
            stmt.setString(5, paciente.getRemedio());
            stmt.setString(6, paciente.getHorarioMedicamento());
            stmt.setString(7, endereco.getRua());
            stmt.setString(8, paciente.getLembrete());
            
            //executa o comando no banco de dados
            stmt.executeUpdate();
            //ResultSet x=stmt.getGeneratedKeys();
            //x.getInt(0)
            
            //fecha a conexão
            stmt.close();
            con.close();
 
        }catch(SQLException e){
            System.out.println("Ocorreu um erro de conexão " + e);
        }
           JOptionPane.showMessageDialog(null, " O Paciente com ID = "+paciente.getId()+
                " foi cadastrado com sucesso!");
       }else{
           JOptionPane.showMessageDialog(null,"TODOS OS CAMPOS DEVEM SER PREENCHIDOS");
       }
            return null;
    }

    @Override
    public Paciente buscarPacientePorId(Integer id) {
        for(Paciente paciente: BancoDeDados.pacienteBDFake){
            if(paciente.getId() == id){
                return paciente;
            }
        } 
        return null;
    }

    @Override
    public List<Paciente> buscarPacientePorNome(String nome) {
        List<Paciente> listaDePacientesEncontrados = new ArrayList<Paciente>();        
        
        for(int i = 0; i< BancoDeDados.pacienteBDFake.size();i++){
            Paciente paciente = BancoDeDados.pacienteBDFake.get(i);
            if(paciente.getNomePaciente().startsWith(nome)){
                listaDePacientesEncontrados.add(paciente);
            }           
        }
        return listaDePacientesEncontrados;
    }

    @Override
    public List<Paciente> buscarTodosPacientes() {
        return BancoDeDados.pacienteBDFake;
    }
    
    public boolean validarPaciente(Paciente paciente){
        boolean clienteValido = true;
        if(paciente !=null)
        {
            if(paciente.getNomePaciente()==null||
                paciente.getNomePaciente().equals("")||
                paciente.getNomeResponsavel()==null||
                paciente.getRemedio()==null||
                paciente.getRemedio().equals("")||
                paciente.getTelefone()==null||
                paciente.getTelefone().equals(""))
                {
                clienteValido = false;
                }
        }
        return clienteValido;
     }


    public boolean validarEndereco(Endereco endereco){
        boolean clienteValido = true;
        if(endereco !=null)
        {
            if(endereco.getRua()== null||
               endereco.getRua().equals(""))
                {
                clienteValido = false;
                }
        }
        return clienteValido;
     }
    
}