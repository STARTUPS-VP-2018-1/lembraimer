package br.com.lembraimer.business;
import br.com.lembraimer.business.interfaces.ResponsavelInterface;
import br.com.lembraimer.dominio.Responsavel;
import br.com.lembraimer.banco.BancoDeDados;
import java.util.ArrayList;
import java.util.List;

public class ResponsavelBusiness implements ResponsavelInterface {

    @Override
    public Responsavel salvarResponsavel(Responsavel responsavel) {
        BancoDeDados.responsavelBDFake.add(responsavel);
            return responsavel;
    }

    @Override
    public List<Responsavel> buscarResponsavelPorNome(String nome) {
        List<Responsavel> listaDeResponsaveisEncontrados = new ArrayList<Responsavel>();        
        
        for(int i = 0; i< BancoDeDados.pacienteBDFake.size();i++){
            Responsavel responsavel = BancoDeDados.responsavelBDFake.get(i);
            if(responsavel.getNomeResponsavel().startsWith(nome)){
                listaDeResponsaveisEncontrados.add(responsavel);
            }           
        }
        return listaDeResponsaveisEncontrados;
    }
    
}