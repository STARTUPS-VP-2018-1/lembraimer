/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.lembraime.business;

import br.com.lembraime.db.dataBase;
import br.com.lembraime.dominio.Endereco;
import br.com.lembraime.dominio.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ponto
 */
public class PacienteBusiness {
Connection con = null;
    

public void  salvarBusiness(Paciente cadastro, Endereco cadastro1) {
        con = dataBase.conexao();
        
       String query = ("INSERT INTO paciente (nomePaciente,nomeResponsavel,telefoneResponsavel,medicamento,horarioMedicamento,endereco,lembretes)VALUES(?,?,?,?,?,?,?)");
       
    try {
        PreparedStatement smtp = con.prepareStatement(query);
        smtp.setString(1, cadastro.getNomePaciente());
        smtp.setString(2, cadastro.getNomeResponsavel());
        smtp.setString(3, String.valueOf(cadastro.getTelefone()));
        smtp.setString(4, cadastro.getRemedio());
        smtp.setString(5, cadastro.getHorarioMedicamento());
        smtp.setString(6, cadastro1.getCidade());
        smtp.setString(7, cadastro.getLembrete());
        
        smtp.executeUpdate();
        dataBase.fecharConexao(con, smtp);
 
    } catch (SQLException ex) {
        Logger.getLogger(PacienteBusiness.class.getName()).log(Level.SEVERE, null, ex);
    }
       
       
    }

    
    
  
    
}
