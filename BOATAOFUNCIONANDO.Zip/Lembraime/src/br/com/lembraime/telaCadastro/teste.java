/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.lembraime.telaCadastro;

import br.com.lembraime.dominio.Paciente;

/**
 *
 * @author Ponto
 */
public class teste extends Paciente{
    private String nome;

public String getNome() {
        return nome;
    }

public void setNome(String nome) {
        this.nome = nome;
    }

    public void puxarNome(Paciente paciente) {
        //JOptionPane.showMessageDialog(null, paciente.getNomePaciente());
        setNome(paciente.getNomePaciente());
        nome = paciente.getNomePaciente();
        System.out.println("teste >" + nome);
    }
}
