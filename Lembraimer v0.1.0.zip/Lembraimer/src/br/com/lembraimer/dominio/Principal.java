package br.com.lembraimer.dominio;

import br.com.lembraimer.tela.TelaPrincipal;


public class Principal {
   public static void main(String[] args) {
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
  
    } 
}
