package br.com.lembraimer.business.interfaces;

import br.com.lembraimer.dominio.Usuario;

public interface UsuarioInterface {
    
    public  boolean checkLogin(String nome, String nomeResponsavel);
    
    public Usuario usuarioLogado(Usuario usuario, Usuario senha);
}
