/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.lembraime.dominio;

/**
 *
 * @author Ponto
 */
public class Paciente {
       private String nomePaciente;
       private double dataDeNascimento;
       private String genero;
       private Integer id;
       private String remedio;
       private String nomeResponsavel;
       private Integer telefone;
       private String horarioMedicamento;
       private String lembrete;

    public String getNomePaciente() {
        return nomePaciente;
    }

    public void setNomePaciente(String nomePaciente) {
        this.nomePaciente = nomePaciente;
    }

    public double getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(double dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRemedio() {
        return remedio;
    }

    public void setRemedio(String remedio) {
        this.remedio = remedio;
    }

    public String getNomeResponsavel() {
        return nomeResponsavel;
    }

    public void setNomeResponsavel(String nomeResponsavel) {
        this.nomeResponsavel = nomeResponsavel;
    }

    public Integer getTelefone() {
        return telefone;
    }

    public void setTelefone(Integer telefone) {
        this.telefone = telefone;
    }

    public String getHorarioMedicamento() {
        return horarioMedicamento;
    }

    public void setHorarioMedicamento(String horarioMedicamento) {
        this.horarioMedicamento = horarioMedicamento;
    }

    public String getLembrete() {
        return lembrete;
    }

    public void setLembrete(String lembrete) {
        this.lembrete = lembrete;
    }
       
       
}
