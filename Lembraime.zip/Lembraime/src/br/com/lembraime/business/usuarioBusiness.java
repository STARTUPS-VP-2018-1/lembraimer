package br.com.lembraime.business;

import br.com.lembraime.db.dataBase;
import br.com.lembraime.dominio.Paciente;
import br.com.lembraime.dominio.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class usuarioBusiness {
    String user;
    String pass;
   
    public boolean ChekLogin(String nome, String nomeResponsavel){
            
    Connection conn = null;
    PreparedStatement cmd = null;
    ResultSet rs = null;
    boolean check = false;
    conn = dataBase.conexao();
        try {
            cmd = conn.prepareStatement("SELECT * FROM paciente where nomePaciente = ? and nomeResponsavel = ?");
            cmd.setString(1, nome);
            cmd.setString(2, nomeResponsavel);
            rs = cmd.executeQuery();
            //user = login;
            //pass = senha;
            while(rs.next()){
                check = true;
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(usuarioBusiness.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
        return check;
    }
    
    public void  notificacao(Paciente nome){        
    Connection conn = null;
    PreparedStatement cmd = null;
    ResultSet rs = null;
        
    conn = dataBase.conexao();
    //Paciente pass = new Paciente();
        try {
            cmd = conn.prepareStatement("SELECT nomeResponsavel from paciente where nomePaciente = ?");
            
            cmd.setString(1, nome.getNomePaciente());
            
            //cmd.setString(2, nome.getNomeResponsavel());
            
            rs = cmd.executeQuery();

            JOptionPane.showMessageDialog(null, nome.getNomeResponsavel());

            dataBase.fecharfecharConexao(conn, cmd, rs);
            
        } catch (SQLException ex) {
            Logger.getLogger(usuarioBusiness.class.getName()).log(Level.SEVERE, null, ex);
        }
    
   
    
    }
     
}
